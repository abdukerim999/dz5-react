import React from 'react';
import NameList from "./components/NameList.jsx";

const App = () => {
    return (
        <div>
            <NameList/>
        </div>
    );
};

export default App;